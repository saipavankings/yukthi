<?php
//get data from form  

$name = $_POST['name'];
$email= $_POST['email'];
$subject= $_Post['subject'];
$message= $_POST['message'];

$to ="yukthimarketingteam@gmail.com";

$subject = "Mail From YukthiMarketing";
$txt ="name = ". $name . "\r\n  email = " . $email . "\r\n subject = " . $subject ."\r\n message = ".$message;

$headers = "From: noreply@yukthimarketing.com" . "\r\n" .
"CC: somebodyelse@example.com";

if($email!=NULL){
    mail($to,$subject,$txt,$headers);
}
//redirect
header("Location:YMthankyou.html");
?>